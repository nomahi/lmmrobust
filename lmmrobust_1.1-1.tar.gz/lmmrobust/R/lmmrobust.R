
#' Cluster-Robust Covariance Estimators for Linear Mixed-Effects Models
#'
#' Compute cluster-robust (sandwich-type) covariance estimators for fixed effects of
#' a linear mixed model fitted by lme4::lmer, with multiple small-sample bias corrections.
#' @param fit an \code{lmerMod} object.
#' @param cluster optional cluster IDs; defaults to the first grouping factor in the fitted model.
#' @param type character; one of "RO","MD","FG","FZ","MB".
#' @param conf.level confidence level for intervals.
#' @param inference "z","t", or "both" for normal or t-based inference (df = G-1).
#' @return A data frame containing estimates, robust SEs, test statistics, p-values, and confidence intervals.
#' @export
lmmrobust <- function(fit, cluster=NULL, type=c("RO","MD","FG","FZ","MB"),
                      conf.level=0.95, inference=c("z","t","both")){
  if(!inherits(fit,"lmerMod")) stop("fit must be lmerMod")
  type <- match.arg(type)
  inference <- match.arg(inference)
  mf <- model.frame(fit)
  y <- model.response(mf)
  X <- model.matrix(fit)
  beta <- lme4::fixef(fit)
  if(is.null(cluster)){
    fr <- lme4::getME(fit,"flist")
    if(length(fr)<1) stop("Cannot infer cluster; provide 'cluster'.")
    cluster <- fr[[1]]
  }
  cluster <- as.factor(cluster)
  G <- nlevels(cluster)
  Zt <- lme4::getME(fit,"Zt")
  Lambdat <- lme4::getME(fit,"Lambdat")
  sigma <- stats::sigma(fit)
  sigma2 <- sigma^2

  .get_Vi <- function(idx){
    Zi_t <- Zt[, idx, drop=FALSE]
    Zi <- as.matrix(Matrix::t(Zi_t))
    LLt <- as.matrix(Matrix::t(Lambdat) %*% Lambdat)
    sigma2 * (diag(1, nrow(Zi)) + Zi %*% LLt %*% t(Zi))
  }

  e <- as.numeric(y - X %*% beta)
  p <- ncol(X)
  XtVinvX <- matrix(0, p, p)
  for(g in levels(cluster)){
    idx <- which(cluster==g)
    Xg <- X[idx,,drop=FALSE]
    Vi <- .get_Vi(idx)
    Vinv <- chol2inv(chol(Vi))
    XtVinvX <- XtVinvX + crossprod(Xg, Vinv %*% Xg)
  }
  B <- solve(XtVinvX)

  meat <- matrix(0, p, p)
  for(g in levels(cluster)){
    idx <- which(cluster==g)
    Xg <- X[idx,,drop=FALSE]
    eg <- e[idx]
    Vi <- .get_Vi(idx)
    Vinv <- chol2inv(chol(Vi))
    Ug <- crossprod(Xg, Vinv %*% eg)
    if(type == "RO" || type == "MB"){
      meat <- meat + Ug %*% t(Ug)
    } else {
      Hii <- Xg %*% B %*% t(Xg) %*% Vinv
      Mi <- diag(1, nrow(Hii)) - Hii
      ev <- eigen(Mi, symmetric=TRUE, only.values=TRUE)$values
      if(any(ev <= 1e-8)) Mi <- Mi + diag(1e-6, nrow(Mi))
      if(type == "MD"){
        e_star <- as.numeric(solve(Mi, eg))
      } else if(type == "FG"){
        ev2 <- eigen(solve(Mi), symmetric=TRUE, only.values=TRUE)$values
        b <- min(1, p / sum(ev2))
        Adj <- b * solve(Mi) + (1-b) * diag(1, nrow(Mi))
        e_star <- as.numeric(Adj %*% eg)
      } else if(type == "FZ"){
        ev3 <- eigen(Mi, symmetric=TRUE)
        Dm12 <- ev3$vectors %*% diag(1/pmax(sqrt(pmax(ev3$values,1e-8)),1e-8)) %*% t(ev3$vectors)
        e_star <- as.numeric(Dm12 %*% eg)
      }
      Ug_star <- crossprod(Xg, Vinv %*% e_star)
      meat <- meat + Ug_star %*% t(Ug_star)
    }
  }
  if(type == "MB"){
    N <- nrow(X)
    meat <- (G/(G-1)) * (N/(N-p)) * meat
  }
  V <- B %*% meat %*% B

  se <- sqrt(diag(V))
  est <- as.numeric(beta); names(est) <- names(beta)
  alpha <- 1 - conf.level
  zcrit <- stats::qnorm(1 - alpha/2)
  stat <- est / se
  p_z <- 2*(1 - stats::pnorm(abs(stat)))
  ciL_z <- est - zcrit*se; ciU_z <- est + zcrit*se
  df_t <- G - 1L
  tcrit <- stats::qt(1 - alpha/2, df=df_t)
  p_t <- 2*(1 - stats::pt(abs(stat), df=df_t))
  ciL_t <- est - tcrit*se; ciU_t <- est + tcrit*se

  make_df <- function(inf){
    if(inf=="z"){
      data.frame(estimate=est, std.error=se,
                 stat=stat, p.value=p_z, conf.low=ciL_z, conf.high=ciU_z,
                 inference="z", type=type, df=NA_integer_, stringsAsFactors=FALSE, row.names=names(beta))
    } else {
      data.frame(estimate=est, std.error=se,
                 stat=stat, p.value=p_t, conf.low=ciL_t, conf.high=ciU_t,
                 inference="t", type=type, df=df_t, stringsAsFactors=FALSE, row.names=names(beta))
    }
  }
  out <- switch(inference,
                "z"=make_df("z"),
                "t"=make_df("t"),
                "both"=rbind(make_df("z"), make_df("t")))
  class(out) <- c("lmmrobust","data.frame")
  attr(out,"vcov") <- V
  attr(out,"type") <- type
  attr(out,"df") <- df_t
  out
}

#' @export
print.lmmrobust <- function(x, digits=4, ...){
  ty <- unique(x$type)
  infs <- unique(x$inference)
  cat("Cluster-robust inference for lmer fixed effects [type =", ty, "] (inference:", paste(infs, collapse="/"), ")\n")
  df <- x[, c("term","estimate","std.error","stat","p.value","conf.low","conf.high","inference","df")]
  names(df) <- c("Term","Estimate","Std.Err","t/z","Pr(>|.|)","CI.low","CI.high","Inference","df")
  print.data.frame(df, digits=digits, row.names=FALSE)
  invisible(x)
}
